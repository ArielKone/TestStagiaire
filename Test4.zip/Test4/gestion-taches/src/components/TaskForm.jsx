import React, { useState } from 'react';
import './TaskForm.css';

const TaskForm = ({ addTask, toggleForm }) => {
  const [id, setId] = useState(Date.now()); 
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [status, setStatus] = useState('À faire');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (title && startDate) {
      addTask({
        id,
        title,
        description,
        startDate,
        status,
      });
      setId(Date.now()); 
      setTitle('');
      setDescription('');
      setStartDate('');
      setStatus('À faire');
      toggleForm();
    }
  };

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <input
        type="text"
        value={id}
        readOnly 
        placeholder="ID"
      />
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Titre"
        required
      />
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Description"
      ></textarea>
      <input
        type="datetime-local"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
        required
      />
      <select
        value={status}
        onChange={(e) => setStatus(e.target.value)}
      >
        <option value="À faire">À faire</option>
        <option value="En cours">En cours</option>
        <option value="Terminé">Terminé</option>
      </select>
      <button type="submit">Ajouter Tâche</button>
    </form>
  );
};

export default TaskForm;
