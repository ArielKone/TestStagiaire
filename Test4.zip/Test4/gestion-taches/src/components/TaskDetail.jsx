import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './TaskDetail.css';

const TaskDetail = ({ tasks, updateTaskStatus }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const task = tasks.find((task) => task.id === parseInt(id));

  if (!task) {
    return <p>Tâche non trouvée</p>;
  }

  const handleStatusUpdate = (status) => {
    updateTaskStatus(task.id, status);
    navigate('/');
  };

  return (
    <div className="task-detail-container">
      <header className="task-detail-header">
        <h2>Détail : {task.title}</h2>
        <div className="task-detail-status-buttons">
          <button className="status-button in-progress" onClick={() => handleStatusUpdate('En cours')}>Commencer</button>
          <button className="status-button done" onClick={() => handleStatusUpdate('Terminé')}>Terminer</button>
        </div>
      </header>
      <article className="task-detail">
        <h3>Détail</h3>
        <section>
          <p><strong>ID :</strong> {task.id}</p>
          <p><strong>Description :</strong> {task.description}</p>
          <p><strong>Date de début :</strong> {task.startDate}</p>
          <p><strong>Statut :</strong> {task.status}</p>
        </section>
        <footer>
          <button onClick={() => navigate('/')} className="quit-button">Quitter</button>
        </footer>
      </article>
    </div>
  );
};

export default TaskDetail;
