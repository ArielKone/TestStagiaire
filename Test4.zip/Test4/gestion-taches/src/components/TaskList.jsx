import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import TaskForm from './TaskForm';
import './TaskList.css';

const TaskList = ({ tasks, deleteTask, updateTaskStatus, addTask, updateTask }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [editingTaskId, setEditingTaskId] = useState(null);
  const [editedTask, setEditedTask] = useState({ id: '', title: '', startDate: '', status: '' });
  const [showForm, setShowForm] = useState(false);
  const tasksPerPage = 5;

  const indexOfLastTask = currentPage * tasksPerPage;
  const indexOfFirstTask = indexOfLastTask - tasksPerPage;
  const currentTasks = tasks.slice(indexOfFirstTask, indexOfLastTask);

  const statusColors = {
    'À faire': 'red',
    'En cours': 'orange',
    'Terminé': 'green'
  };

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const handleEditClick = (task) => {
    setEditingTaskId(task.id);
    setEditedTask({ id: task.id, title: task.title, startDate: task.startDate, status: task.status });
  };

  const handleSaveClick = () => {
    updateTask(editingTaskId, editedTask);
    setEditingTaskId(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedTask(prevState => ({ ...prevState, [name]: value }));
  };

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  return (
    <div className="task-list-container">
      <div className="task-status-cards">
        <div className="task-status-card" style={{ backgroundColor: 'red' }}>
          <h3>À faire</h3>
          <p>{tasks.filter(task => task.status === 'À faire').length}</p>
        </div>
        <div className="task-status-card" style={{ backgroundColor: 'orange' }}>
          <h3>En cours</h3>
          <p>{tasks.filter(task => task.status === 'En cours').length}</p>
        </div>
        <div className="task-status-card" style={{ backgroundColor: 'green' }}>
          <h3>Terminé</h3>
          <p>{tasks.filter(task => task.status === 'Terminé').length}</p>
        </div>
      </div>
      
      <table className="task-list-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Titre</th>
            <th>Date de début</th>
            <th>Statut</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentTasks.map((task, index) => (
            <tr key={task.id}>
              <td>{task.id}</td>
              <td>
                {editingTaskId === task.id ? (
                  <input
                    type="text"
                    name="title"
                    value={editedTask.title}
                    onChange={handleChange}
                  />
                ) : (
                  task.title
                )}
              </td>
              <td>
                {editingTaskId === task.id ? (
                  <input
                    type="date"
                    name="startDate"
                    value={editedTask.startDate}
                    onChange={handleChange}
                  />
                ) : (
                  task.startDate
                )}
              </td>
              <td style={{ color: statusColors[task.status] }}>
                {editingTaskId === task.id ? (
                  <select name="status" value={editedTask.status} onChange={handleChange}>
                    <option value="À faire">À faire</option>
                    <option value="En cours">En cours</option>
                    <option value="Terminé">Terminé</option>
                  </select>
                ) : (
                  task.status
                )}
              </td>
              <td>
                {editingTaskId === task.id ? (
                  <>
                    <button onClick={handleSaveClick}>💾</button>
                    <button onClick={() => setEditingTaskId(null)}>❌</button>
                  </>
                ) : (
                  <>
                    <Link to={`/tasks/${task.id}`}>Detail</Link>
                    <button onClick={() => updateTaskStatus(task.id, 'En cours')}>🕑</button>
                    <button onClick={() => updateTaskStatus(task.id, 'Terminé')}>✅</button>
                    <button onClick={() => deleteTask(task.id)}>❌</button>
                    <button onClick={() => handleEditClick(task)}>✏️</button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      <div className="pagination">
        {Array.from({ length: Math.ceil(tasks.length / tasksPerPage) }, (_, index) => (
          <button
            key={index + 1}
            onClick={() => paginate(index + 1)}
            style={{
              paddingTop: '5px',
              backgroundColor: index + 1 === currentPage ? 'black' : 'gray',
              color: index + 1 === currentPage ? 'white' : 'black',
              border: 'none',
              cursor: 'pointer',
              padding: '5px 10px',
              margin: '0 5px',
              borderRadius: '3px'
            }}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TaskList;
