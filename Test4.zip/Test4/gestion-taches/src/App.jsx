import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';
import TaskDetail from './components/TaskDetail';
import './App.css';

const App = () => {
  const [tasks, setTasks] = useState([]);
  const [showForm, setShowForm] = useState(false);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const updateTaskStatus = (id, status) => {
    setTasks(tasks.map(task => task.id === id ? { ...task, status: status } : task));
  };

  const updateTask = (id, updatedTask) => {
    setTasks(tasks.map(task => task.id === id ? { ...task, ...updatedTask } : task));
  };

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  return (
    <Router>
      <div className="app">
        {/* <Header /> */}
        <main className="main-content">
          <div className="header-container">
            <h1>Bienvenue sur GesTâche</h1>
            <button onClick={toggleForm} className="add-task-button">
              {showForm ? 'Annuler' : 'Ajouter une tâche'}
            </button>
          </div>
          {showForm && (
            <div className="modal">
              <div className="modal-content">
                <span className="close-button" onClick={toggleForm}>&times;</span>
                <TaskForm addTask={addTask} toggleForm={toggleForm} />
              </div>
            </div>
          )}
          <Routes>
            <Route path="/" element={
              <TaskList 
                tasks={tasks} 
                deleteTask={deleteTask} 
                updateTaskStatus={updateTaskStatus} 
                updateTask={updateTask} 
                addTask={addTask}
              />
            } />
            <Route path="/tasks/:id" element={<TaskDetail tasks={tasks} updateTaskStatus={updateTaskStatus} />} />
          </Routes>
        </main>
        {/* <Footer /> */}
      </div>
    </Router>
  );
};

export default App;
