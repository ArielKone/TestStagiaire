# Gestion des Tâches

## Description
Une application web en ReactJS pour gérer des tâches. Elle permet d'ajouter des tâches, de les afficher sous forme de liste, et de voir les détails de chaque tâche.

## Installation

1. Clonez le dépôt :
   ```bash
   git clone <url-du-dépôt>
   cd gestion-taches
2. Installez les dépendances :
    
    npm install
3. Démarrez l'application :
    
    npm run dev
